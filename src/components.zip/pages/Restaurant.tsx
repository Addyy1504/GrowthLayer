import { useEffect } from "react";
import { motion, easeOut, Variants } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import Footer from "../components/Footer";
import HeroImage from "../assets/RestaurantHero.png";
import RestaurantMockup from "../assets/RestaurantMockup.png";
import CountUp from "react-countup";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.15, duration: 0.6, ease: easeOut },
  }),
};

export default function Restaurant() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleScrollToContact = () => {
    if (location.pathname === "/") {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
    } else {
      navigate("/");
      setTimeout(() => {
        document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
      }, 300);
    }
  };

  const automationFlow = [
    {
      title: "Customer Visit Logged",
      desc: "After each visit, staff records basic customer details in a digital sheet to enable smooth re-engagement and insights tracking.",
    },
    {
      title: "Feedback Collection",
      desc: "After dining, a WhatsApp message is sent automatically to collect genuine feedback and reviews without manual follow-up.",
    },
    {
      title: "Offer Reminder",
      desc: "After 10–15 days, returning customers get an automated personalized message or offer — helping retain loyal diners effortlessly.",
    },
    {
      title: "Insights Dashboard",
      desc: "All customer data and responses are stored in Google Sheets, allowing restaurant owners to visualize trends and retention rates.",
    },
  ];

  return (
    <div className="bg-white text-black min-h-screen flex flex-col justify-between overflow-hidden">

      {/* 🍽️ HERO SECTION */}
      <section className="bg-[#F8F9FA] pt-36 pb-24">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
              Digitally Empowering Restaurants <span className="text-[#3EF4E4]">.</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-700 leading-relaxed max-w-3xl">
              GrowthLayer helps restaurants stand out online with{" "}
              <span className="font-semibold">beautiful websites, interactive digital menus, and automated WhatsApp follow-ups</span> — 
              turning first-time visitors into loyal regulars without managing any booking systems.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            custom={1}
            className="w-full h-[380px] rounded-3xl overflow-hidden border border-gray-200 shadow-[0_10px_40px_rgba(0,0,0,0.08)]"
          >
            <img src={HeroImage} alt="Restaurant Hero" className="w-full h-full object-cover" />
          </motion.div>
        </div>
      </section>

      {/* ⚙️ AUTOMATION FLOW */}
      <section className="py-28 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.h2
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            className="text-4xl md:text-5xl font-bold mb-16"
          >
            Our Automation Flow<span className="text-[#3EF4E4]">.</span>
          </motion.h2>

          <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-10">
            {automationFlow.map((step, i) => (
              <motion.div
                key={i}
                initial="hidden"
                whileInView="visible"
                variants={fadeUp}
                custom={i}
                className="relative bg-white rounded-3xl border border-gray-100 
                           shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_10px_40px_rgba(62,244,228,0.25)] 
                           px-8 py-12 text-left transition-all duration-500 transform hover:-translate-y-2"
              >
                {/* Aqua Badge */}
                <div className="absolute -top-6 left-6 bg-[#3EF4E4] text-black text-xl font-bold 
                                rounded-full h-12 w-12 flex items-center justify-center shadow-md">
                  {(i + 1).toString().padStart(2, "0")}
                </div>

                <h3 className="text-xl md:text-2xl font-semibold mb-3 mt-6">{step.title}</h3>
                <p className="text-gray-700 text-sm md:text-base leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 🌐 WEBSITE EXPERIENCE */}
      <section className="py-28 bg-[#F8F9FA] text-center">
        <motion.h2
          initial="hidden"
          whileInView="visible"
          variants={fadeUp}
          className="text-4xl md:text-5xl font-black mb-10"
        >
          Building the <span className="text-[#3EF4E4]">Digital Face</span> of Every Restaurant.
        </motion.h2>

        <p className="text-gray-700 text-lg max-w-3xl mx-auto mb-16 leading-relaxed">
          A great dining experience begins online. We design modern, mobile-friendly websites that showcase your 
          cuisine, story, and atmosphere — paired with digital menus and WhatsApp automation that keeps customers coming back.
        </p>

        <div className="relative mx-auto mb-20 max-w-5xl rounded-3xl overflow-hidden border border-gray-200 shadow-lg">
          <img
            src={RestaurantMockup}
            alt="Restaurant Website Mockup"
            className="w-full h-[420px] object-cover opacity-95 hover:opacity-100 transition-all duration-500"
          />
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto px-6">
          {[
            { title: "Showcase Your Menu", desc: "Turn your menu into an interactive experience that customers can browse effortlessly." },
            { title: "Boost Online Presence", desc: "Appear on Google, highlight your ambiance, and build credibility with a sleek website." },
            { title: "Automate Engagement", desc: "Pair your site with GrowthLayer WhatsApp automation for retention-driven marketing." },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial="hidden"
              whileInView="visible"
              variants={fadeUp}
              custom={i}
              className="relative bg-white text-black rounded-3xl px-8 py-12 border border-gray-100 
                         shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_10px_40px_rgba(62,244,228,0.25)]
                         transition-all duration-500 transform hover:-translate-y-2 text-left"
            >
              <div className="absolute -top-6 left-6 bg-[#3EF4E4] text-black text-lg font-bold 
                              rounded-full h-12 w-12 flex items-center justify-center shadow-md">
                {(i + 1).toString().padStart(2, "0")}
              </div>
              <h3 className="text-xl font-bold mb-3 mt-6">{item.title}</h3>
              <p className="text-gray-700 text-sm md:text-base leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 📈 RESULTS SECTION */}
      <section className="relative bg-[#0D0D0D] py-28 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-black mb-6">
            The Impact<span className="text-[#3EF4E4]">.</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto mb-20 leading-relaxed">
            Restaurants using GrowthLayer’s websites and automation systems have seen higher engagement, 
            improved retention, and consistent visibility — all without manual follow-ups.
          </p>

          <div className="grid sm:grid-cols-3 gap-10">
            {[
              { value: 30, suffix: "%", label: "Increase in Repeat Visits" },
              { value: 100, suffix: "%", label: "Automated Feedback Collection" },
              { value: 3, suffix: "x", label: "Stronger Online Visibility" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: i * 0.15 }}
                viewport={{ once: true }}
                className="bg-[#101010] rounded-3xl border border-[#3EF4E4]/30 hover:border-[#3EF4E4] transition-all 
                           shadow-[0_0_30px_rgba(62,244,228,0.05)] hover:shadow-[0_0_50px_rgba(62,244,228,0.15)]
                           p-10 text-center transform hover:-translate-y-2 duration-500"
              >
                <h3 className="text-6xl md:text-7xl font-black text-[#3EF4E4] mb-4">
                  <CountUp end={stat.value} duration={2.5} enableScrollSpy scrollSpyOnce />
                  {stat.suffix}
                </h3>
                <p className="text-gray-300 text-lg font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 🧲 CTA */}
      <motion.section
        initial="hidden"
        whileInView="visible"
        variants={fadeUp}
        viewport={{ once: true }}
        className="py-20 bg-[#3EF4E4] text-black text-center"
      >
        <h2 className="text-4xl font-bold mb-4">Let’s Digitize Your Restaurant.</h2>
        <p className="text-lg max-w-2xl mx-auto mb-8 opacity-90">
          Build a digital experience your customers will love — from menu browsing to instant WhatsApp engagement — powered by GrowthLayer.
        </p>
        <button
          onClick={handleScrollToContact}
          className="px-10 py-4 bg-black text-white rounded-full font-bold hover:scale-105 transition-transform"
        >
          Get Started
        </button>
      </motion.section>

      <Footer />
    </div>
  );
}
