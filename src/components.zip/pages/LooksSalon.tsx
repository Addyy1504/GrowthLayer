import { useEffect } from "react";
import { motion, easeOut, Variants } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import { Workflow, MessageSquare, Users, BarChart } from "lucide-react";
import CountUp from "react-countup";
import Footer from "../components/Footer";
import HeroImage from "../assets/LooksSalon.png";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.15,
      duration: 0.7,
      ease: easeOut,
    },
  }),
};

export default function LooksSalon() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => window.scrollTo(0, 0), []);

  const handleScrollToContact = () => {
    if (location.pathname === "/") {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
    } else {
      navigate("/");
      setTimeout(() => {
        document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
      }, 300);
    }
  };

  const automationFlow = [
    {
      title: "Visit Logged",
      desc: "Reception staff adds client name, phone, and service details digitally after each appointment.",
    },
    {
      title: "Feedback Automation",
      desc: "A WhatsApp message automatically asks for feedback after their visit — no manual calls needed.",
    },
    {
      title: "Re-Engagement Reminder",
      desc: "After 21–30 days, clients receive a personalized WhatsApp message to rebook.",
    },
    {
      title: "Insight Dashboard",
      desc: "All feedback and data sync automatically to Google Sheets for clear tracking.",
    },
  ];

  return (
    <div className="bg-white text-black min-h-screen flex flex-col justify-between overflow-hidden">

      {/* 🏁 HERO SECTION */}
      <section className="bg-[#F8F9FA] pt-36 pb-28">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-14 items-center">
          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
              Automating Salon Growth<span className="text-[#3EF4E4]">.</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-700 leading-relaxed max-w-3xl">
              We help salons move from manual chaos to automated clarity — building retention systems,
              automating WhatsApp communication, and turning every visit into a relationship.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            custom={1}
            className="w-full h-[420px] rounded-3xl overflow-hidden border border-gray-200 shadow-[0_10px_40px_rgba(0,0,0,0.08)]"
          >
            <img
              src={HeroImage}
              alt="Looks Salon Hero"
              className="w-full h-full object-cover object-center"
            />
          </motion.div>
        </div>
      </section>

      {/* 💡 WHAT WE DO */}
      <section className="py-24 bg-white text-center">
        <motion.h2
          initial="hidden"
          whileInView="visible"
          variants={fadeUp}
          className="text-4xl md:text-5xl font-bold mb-10"
        >
          What We Build for Salons<span className="text-[#3EF4E4]">.</span>
        </motion.h2>

        <p className="text-gray-700 text-lg max-w-3xl mx-auto mb-16">
          GrowthLayer crafts an end-to-end digital ecosystem for salons — combining websites, automation, and analytics to maximize client retention and experience.
        </p>

        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-10 px-6">
          {[
            {
              title: "Automated Client Retention",
              desc: "Personalized WhatsApp messages for feedback, reviews, and rebooking.",
            },
            {
              title: "Digital Feedback System",
              desc: "Every client visit tracked and responded to, without manual calls.",
            },
            {
              title: "Insights & Data Dashboard",
              desc: "Google Sheets dashboards showing trends, feedback, and re-engagement rates.",
            },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              custom={i}
              className="relative bg-[#3EF4E4] text-black rounded-3xl px-10 py-12 shadow-[0_10px_30px_rgba(62,244,228,0.3)] transition-all hover:-translate-y-2"
            >
              <div className="absolute -top-6 left-6 bg-white text-black text-lg font-bold rounded-full h-12 w-12 flex items-center justify-center shadow-md">
                {(i + 1).toString().padStart(2, "0")}
              </div>
              <h3 className="text-2xl font-bold mb-4 mt-6">{item.title}</h3>
              <p className="text-gray-900 text-base leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ⚙️ AUTOMATION FLOW */}
      <section className="py-28 bg-[#F8F9FA] relative">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.h2
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            className="text-4xl md:text-5xl font-bold mb-20"
          >
            The Salon Automation Flow
          </motion.h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-12">
            {automationFlow.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                viewport={{ once: true }}
                className="relative p-10 rounded-3xl bg-white border border-gray-200 
                           shadow-[0_6px_30px_rgba(0,0,0,0.05)] hover:border-[#3EF4E4] hover:shadow-[0_0_30px_rgba(62,244,228,0.2)]
                           transition-all duration-500"
              >
                <div className="absolute -top-6 left-6 bg-[#3EF4E4] text-black text-2xl font-bold 
                                rounded-full h-12 w-12 flex items-center justify-center shadow-md">
                  {(i + 1).toString().padStart(2, "0")}
                </div>
                <h3 className="text-lg md:text-xl font-semibold mb-3 mt-6">{step.title}</h3>
                <p className="text-gray-700 text-sm md:text-base leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 🏆 CASE STUDY — LOOKS SALON */}
      <section className="py-28 bg-gradient-to-b from-white via-[#F8F9FA] to-[#E6FFFB]">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            className="rounded-3xl overflow-hidden border border-gray-200 shadow-[0_10px_50px_rgba(0,0,0,0.08)]"
          >
            <img
              src={HeroImage}
              alt="Looks Salon Automation Example"
              className="w-full h-[600px] object-cover object-center"
            />
          </motion.div>

          {/* Text Side */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            custom={1}
          >
            <h2 className="text-4xl md:text-5xl font-black mb-6 leading-tight">
              Looks Salon Noida Transformation<span className="text-[#3EF4E4]">.</span>
            </h2>
            <p className="text-gray-700 text-lg leading-relaxed mb-8">
              We partnered with <span className="font-semibold text-black">Looks Salon (Rcube Monad Mall, Noida)</span> 
              to modernize their client management system. Our automation replaced manual follow-ups
              with WhatsApp-driven communication — ensuring no client is ever forgotten.
            </p>

            <div className="grid grid-cols-2 gap-6 text-left">
              <div>
                <h4 className="font-bold text-black mb-2">Before GrowthLayer</h4>
                <ul className="text-gray-700 text-sm space-y-1 list-disc list-inside">
                  <li>Manual calls for feedback</li>
                  <li>Missed retention opportunities</li>
                  <li>Untracked client data</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-black mb-2">After GrowthLayer</h4>
                <ul className="text-gray-700 text-sm space-y-1 list-disc list-inside">
                  <li>Automated WhatsApp flows</li>
                  <li>100% feedback collected</li>
                  <li>+40% client revisits</li>
                </ul>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 📈 RESULTS */}
      <section className="relative bg-[#0D0D0D] py-28 text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-black mb-10">
            The Results<span className="text-[#3EF4E4]">.</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto mb-20 leading-relaxed">
            The integration of automation and feedback loops transformed client experience at Looks Salon.
            Every client now receives timely reminders and feedback links — strengthening relationships and retention.
          </p>

          <div className="grid sm:grid-cols-3 gap-10">
            {[
              { value: 40, suffix: "%", label: "Increase in Client Revisits" },
              { value: 100, suffix: "%", label: "Automated Follow-Ups" },
              { value: 2, suffix: "x", label: "Faster Feedback & Insights" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: i * 0.15 }}
                viewport={{ once: true }}
                className="bg-[#101010] rounded-3xl border border-[#3EF4E4]/30 hover:border-[#3EF4E4] 
                           shadow-[0_0_40px_rgba(62,244,228,0.1)] hover:shadow-[0_0_60px_rgba(62,244,228,0.25)]
                           p-10 text-center transform hover:-translate-y-2 duration-500"
              >
                <h3 className="text-5xl md:text-6xl font-black text-[#3EF4E4] mb-3">
                  <CountUp end={stat.value} duration={2.5} enableScrollSpy scrollSpyOnce />
                  {stat.suffix}
                </h3>
                <p className="text-gray-300 text-sm font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <motion.section
        initial="hidden"
        whileInView="visible"
        variants={fadeUp}
        viewport={{ once: true }}
        className="py-20 bg-[#3EF4E4] text-black text-center"
      >
        <h2 className="text-4xl font-bold mb-4">Let’s Automate Your Salon.</h2>
        <p className="text-lg max-w-2xl mx-auto mb-8 opacity-90">
          Create a complete digital system — retention, feedback, and rebooking — built for modern salons.
        </p>
        <button
          onClick={handleScrollToContact}
          className="px-10 py-4 bg-black text-white rounded-full font-bold hover:scale-105 transition-transform"
        >
          Get Started
        </button>
      </motion.section>

      <Footer />
    </div>
  );
}
