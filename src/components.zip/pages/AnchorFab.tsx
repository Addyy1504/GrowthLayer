import { useEffect } from "react";
import { motion, easeOut, Variants } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import Footer from "../components/Footer";
import HeroImage from "../assets/ManufacturingHero.png";
import ExampleMockup from "../assets/AnchorFab.png";
import CountUp from "react-countup";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.15, duration: 0.6, ease: easeOut },
  }),
};

export default function ManufacturingEcom() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => window.scrollTo(0, 0), []);

  const handleScrollToContact = () => {
    if (location.pathname === "/") {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
    } else {
      navigate("/");
      setTimeout(() => {
        document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
      }, 300);
    }
  };

  const benefits = [
    {
      title: "Showcase Products Elegantly",
      desc: "Transform your offline catalog into a modern digital storefront that builds trust and boosts visibility instantly.",
    },
    {
      title: "Attract Quality Leads",
      desc: "Integrated enquiry and WhatsApp flows simplify communication and bring ready-to-convert buyers directly to your inbox.",
    },
    {
      title: "Boost Brand Credibility",
      desc: "A polished, SEO-ready website positions your manufacturing business as a premium and dependable brand.",
    },
    {
      title: "Automate Follow-ups",
      desc: "Re-engage prospects automatically through personalized WhatsApp or email sequences that close deals faster.",
    },
  ];

  const flow = [
    {
      title: "Smart Product Management",
      desc: "Upload or update products instantly via Google Sheets or a CMS — changes reflect on your site in real-time, without any redesign.",
    },
    {
      title: "WhatsApp Enquiry Flow",
      desc: "Each product includes one-tap WhatsApp and form enquiry buttons, reducing manual lead collection efforts.",
    },
    {
      title: "Lead Tracking Dashboard",
      desc: "Every enquiry is automatically logged into a shared Google Sheet or CRM for centralized tracking and follow-up.",
    },
    {
      title: "Re-engagement Automation",
      desc: "Send discount offers, restock alerts, or custom messages to past leads through GrowthLayer Labs automation flows.",
    },
  ];

  return (
    <div className="bg-white text-black min-h-screen flex flex-col justify-between overflow-hidden">
      {/* 🏭 HERO SECTION */}
      <section className="bg-[#F8F9FA] pt-36 pb-24">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
              Digitizing Manufacturing & E-Commerce
              <span className="text-[#3EF4E4]">.</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-700 leading-relaxed max-w-3xl">
              GrowthLayer helps product-based brands go digital with{" "}
              <span className="font-semibold">
                custom websites, Shopify integration, and WhatsApp automation
              </span>{" "}
              — turning outdated catalogs into interactive, lead-driven experiences that scale effortlessly.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            custom={1}
            className="w-full h-[380px] rounded-3xl overflow-hidden border border-gray-200 shadow-[0_10px_40px_rgba(0,0,0,0.08)]"
          >
            <img src={HeroImage} alt="Manufacturing Hero" className="w-full h-full object-cover" />
          </motion.div>
        </div>
      </section>

      {/* 💡 WHY GO DIGITAL */}
      <section className="py-28 bg-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.h2
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            className="text-4xl md:text-5xl font-bold mb-16"
          >
            Why Go Digital<span className="text-[#3EF4E4]">?</span>
          </motion.h2>

          <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-10">
            {benefits.map((b, i) => (
              <motion.div
                key={i}
                initial="hidden"
                whileInView="visible"
                variants={fadeUp}
                custom={i}
                className="relative bg-white rounded-3xl border border-gray-100 
                           shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_10px_40px_rgba(62,244,228,0.25)] 
                           px-8 py-12 text-left transition-all duration-500 transform hover:-translate-y-2"
              >
                <div className="absolute -top-6 left-6 bg-[#3EF4E4] text-black text-xl font-bold 
                                rounded-full h-12 w-12 flex items-center justify-center shadow-md">
                  {(i + 1).toString().padStart(2, "0")}
                </div>

                <h3 className="text-xl md:text-2xl font-semibold mb-3 mt-6">{b.title}</h3>
                <p className="text-gray-700 text-sm md:text-base leading-relaxed">{b.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 🧵 EXAMPLE WEBSITE */}
      <section className="py-28 bg-[#F8F9FA] relative overflow-hidden">
        {/* 🧵 CASE STUDY — Anchor Fab */}
<section className="py-28 bg-[#F8F9FA] relative overflow-hidden">
  <div className="max-w-7xl mx-auto px-6">
    <motion.h2
      initial="hidden"
      whileInView="visible"
      variants={fadeUp}
      className="text-4xl md:text-5xl font-black text-center mb-20"
    >
      Anchor Fab — Corporate Apparel Manufacturer
      <span className="text-[#3EF4E4]">.</span>
    </motion.h2>

    <div className="relative flex flex-col md:flex-row items-center gap-12">
      {/* 🖼️ Website Mockup */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        variants={fadeUp}
        className="relative w-full md:w-1/2 rounded-3xl overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.08)]"
      >
        <img
          src={ExampleMockup}
          alt="Anchor Fab Website"
          className="w-full h-[480px] object-cover hover:scale-[1.03] transition-transform duration-700"
        />
      </motion.div>

      {/* 📝 Narrative Text */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        variants={fadeUp}
        custom={1}
        className="md:w-1/2 bg-white rounded-3xl p-10 border border-gray-100 shadow-[0_10px_40px_rgba(0,0,0,0.06)]"
      >
        <h3 className="text-3xl font-bold mb-4 text-[#111]">
          Modernizing Manufacturing for the Digital Age
        </h3>
        <p className="text-gray-700 text-lg leading-relaxed mb-4">
          Anchor Fab wanted a professional identity that matched their
          decades-old reputation in corporate apparel. GrowthLayer delivered a
          clean, product-focused website designed for conversion — complete with
          real-time enquiry capture and easy backend updates.
        </p>
        <p className="text-gray-700 text-lg leading-relaxed">
          The CMS lets the team upload new products or categories instantly, and
          the structure is already compatible with Shopify migration — making
          expansion to full e-commerce just one step away.
        </p>
      </motion.div>
    </div>
  </div>
</section>


        {/* ⚙️ FLOW SECTION */}
        <div className="max-w-7xl mx-auto px-6 mt-24 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-16">
            Our Automation Flow<span className="text-[#3EF4E4]">.</span>
          </h2>

          <div className="grid md:grid-cols-4 gap-8">
            {flow.map((item, i) => (
              <motion.div
                key={i}
                initial="hidden"
                whileInView="visible"
                variants={fadeUp}
                custom={i}
                className="relative bg-white text-black rounded-3xl px-8 py-12 border border-gray-100 
                           shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_10px_40px_rgba(62,244,228,0.25)]
                           transition-all duration-500 transform hover:-translate-y-2 text-left"
              >
                <div className="absolute -top-5 left-5 bg-[#3EF4E4] text-black font-bold rounded-full w-10 h-10 flex items-center justify-center text-lg shadow-md">
                  {(i + 1).toString().padStart(2, "0")}
                </div>
                <h3 className="text-xl font-bold mb-3 mt-4">{item.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 📈 RESULTS SECTION */}
      <section className="relative bg-[#0D0D0D] py-28 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-black mb-6">
            The Impact<span className="text-[#3EF4E4]">.</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto mb-20 leading-relaxed">
            Manufacturers adopting GrowthLayer’s digital ecosystem experienced higher conversion rates,
            reduced manual lead management, and faster enquiry response cycles.
          </p>

          <div className="grid sm:grid-cols-3 gap-10">
            {[
              { value: 2, suffix: "x", label: "Increase in Qualified Leads" },
              { value: 50, suffix: "%", label: "Faster Enquiry Responses" },
              { value: 3, suffix: "x", label: "Higher Engagement Rate" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: i * 0.15 }}
                viewport={{ once: true }}
                className="bg-[#101010] rounded-3xl border border-[#3EF4E4]/30 hover:border-[#3EF4E4] transition-all 
                           shadow-[0_0_30px_rgba(62,244,228,0.05)] hover:shadow-[0_0_50px_rgba(62,244,228,0.15)]
                           p-10 text-center transform hover:-translate-y-2 duration-500"
              >
                <h3 className="text-6xl md:text-7xl font-black text-[#3EF4E4] mb-4">
                  <CountUp end={stat.value} duration={2.5} enableScrollSpy scrollSpyOnce />
                  {stat.suffix}
                </h3>
                <p className="text-gray-300 text-lg font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 🧲 CTA */}
      <motion.section
        initial="hidden"
        whileInView="visible"
        variants={fadeUp}
        viewport={{ once: true }}
        className="py-20 bg-[#3EF4E4] text-black text-center"
      >
        <h2 className="text-4xl font-bold mb-4">
          Let’s Digitize Your Manufacturing or E-Commerce Brand.
        </h2>
        <p className="text-lg max-w-2xl mx-auto mb-8 opacity-90">
          Build your digital ecosystem with GrowthLayer — from website design and Shopify-ready
          architecture to enquiry automation and CRM integrations.
        </p>
        <button
          onClick={handleScrollToContact}
          className="px-10 py-4 bg-black text-white rounded-full font-bold hover:scale-105 transition-transform"
        >
          Get Started
        </button>
      </motion.section>

      <Footer />
    </div>
  );
}
