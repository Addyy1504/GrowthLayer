import { useEffect } from "react";
import { motion, easeOut, Variants } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import Footer from "../components/Footer";
import HeroImage from "../assets/real-estate-hero.jpg";
import Munjal from "../assets/munjal.png";
import Kumar from "../assets/kumar.png";
import CountUp from "react-countup";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.15, duration: 0.7, ease: easeOut },
  }),
};

export default function RealEstate() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => window.scrollTo(0, 0), []);

  const handleScrollToContact = () => {
    if (location.pathname === "/") {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
    } else {
      navigate("/");
      setTimeout(() => {
        document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
      }, 300);
    }
  };

  const benefits = [
    {
      title: "Lead-Focused Design",
      desc: "Websites built to convert — guiding every visitor into a qualified lead through seamless UI and CTAs.",
    },
    {
      title: "Premium Brand Image",
      desc: "Transform legacy builder brands into digital-first, trust-driven experiences.",
    },
    {
      title: "Immersive Visual Storytelling",
      desc: "Minimal, cinematic layouts that make every project look aspirational and exclusive.",
    },
    {
      title: "WhatsApp + Call Integration",
      desc: "One-tap enquiry and callback flows that boost engagement and response time.",
    },
  ];

  const process = [
    {
      step: "01",
      title: "Discovery & Positioning",
      desc: "Understanding your audience, brand value, and sales funnel to shape a high-intent web experience.",
    },
    {
      step: "02",
      title: "Design & Development",
      desc: "We create minimal yet striking websites that blend real estate visuals with fast, lead-oriented UX.",
    },
    {
      step: "03",
      title: "Automation & Analytics",
      desc: "Integrating WhatsApp, Google Sheets, and lead tracking systems for end-to-end visibility.",
    },
  ];

  return (
    <div className="bg-white text-black min-h-screen flex flex-col justify-between overflow-hidden">

      {/* 🏙️ HERO SECTION */}
      <section className="bg-[#F8F9FA] pt-36 pb-24">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-14 items-center">
          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
              Elevating Real Estate Brands<span className="text-[#3EF4E4]">.</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-700 leading-relaxed max-w-3xl">
              GrowthLayer builds <span className="font-semibold">digital ecosystems for real estate brands</span> —
              merging modern web design, automation, and storytelling to drive trust and conversions.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            custom={1}
            className="w-full h-[420px] rounded-3xl overflow-hidden border border-gray-200 shadow-[0_10px_40px_rgba(0,0,0,0.08)]"
          >
            <img src={HeroImage} alt="Real Estate Hero" className="w-full h-full object-cover object-center" />
          </motion.div>
        </div>
      </section>

      {/* 💼 WHAT WE DO */}
      <section className="py-24 bg-white text-center">
        <motion.h2
          initial="hidden"
          whileInView="visible"
          variants={fadeUp}
          className="text-4xl md:text-5xl font-bold mb-10"
        >
          What We Build for Builders<span className="text-[#3EF4E4]">.</span>
        </motion.h2>

        <p className="text-gray-700 text-lg max-w-3xl mx-auto mb-16">
          From portfolio websites to automated enquiry systems — we help builders, architects, and developers 
          turn credibility into conversions through data-driven design.
        </p>

        <div className="max-w-6xl mx-auto grid md:grid-cols-4 gap-8 px-6">
          {benefits.map((b, i) => (
            <motion.div
              key={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              custom={i}
              className="relative bg-[#3EF4E4] text-black rounded-3xl px-8 py-12 
                         shadow-[0_10px_30px_rgba(62,244,228,0.25)] transition-all hover:-translate-y-2"
            >
              <div className="absolute -top-6 left-6 bg-white text-black text-lg font-bold rounded-full h-12 w-12 flex items-center justify-center shadow-md">
                {(i + 1).toString().padStart(2, "0")}
              </div>
              <h3 className="text-xl font-bold mb-3 mt-6">{b.title}</h3>
              <p className="text-gray-900 text-base leading-relaxed">{b.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ⚙️ OUR PROCESS */}
<section className="py-28 bg-[#F8F9FA] text-center">
  <motion.h2
    initial="hidden"
    whileInView="visible"
    variants={fadeUp}
    className="text-4xl md:text-5xl font-bold mb-10"
  >
    Our Process<span className="text-[#3EF4E4]">.</span>
  </motion.h2>

  <p className="text-gray-700 text-lg max-w-3xl mx-auto mb-16 leading-relaxed">
    Every GrowthLayer project follows a structured approach — combining strategy, design, 
    and automation to help real estate brands grow with confidence.
  </p>

  <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 px-6">
    {[
      {
        step: "01",
        title: "Discovery & Strategy",
        desc: "We understand your brand story, audience, and market — setting the foundation for a strong digital presence.",
      },
      {
        step: "02",
        title: "Design & Development",
        desc: "We craft websites that look luxurious and convert effectively — pairing bold visuals with high-performance UX.",
      },
      {
        step: "03",
        title: "Automation & Analytics",
        desc: "We integrate WhatsApp, lead tracking, and performance dashboards — making your marketing effortless.",
      },
    ].map((p, i) => (
      <motion.div
        key={i}
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: i * 0.15 }}
        viewport={{ once: true }}
        className="relative bg-white text-black rounded-3xl px-8 py-12 border border-gray-100
                   shadow-[0_8px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_10px_40px_rgba(62,244,228,0.25)]
                   transition-all duration-500 transform hover:-translate-y-2"
      >
        {/* Aqua Badge */}
        <div className="absolute -top-6 left-6 bg-[#3EF4E4] text-black font-bold text-lg
                        rounded-full h-12 w-12 flex items-center justify-center shadow-md">
          {p.step}
        </div>

        <h3 className="text-xl md:text-2xl font-bold mb-4 mt-6">{p.title}</h3>
        <p className="text-gray-700 text-sm md:text-base leading-relaxed">{p.desc}</p>
      </motion.div>
    ))}
  </div>
</section>


      {/* 🏗️ FEATURED PROJECTS */}
      <section className="py-28 bg-gradient-to-b from-white via-[#F8F9FA] to-[#E6FFFB] relative overflow-hidden">
        <motion.div
          initial="hidden"
          whileInView="visible"
          variants={fadeUp}
          className="text-center mb-24"
        >
          <h2 className="text-5xl md:text-6xl font-black text-black mb-4">
            Featured Real Estate Projects
          </h2>
          <div className="w-24 h-1 bg-[#3EF4E4] mx-auto rounded-full"></div>
        </motion.div>

        {/* 🌇 Munjal Constructions */}
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center mb-28">
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            className="rounded-3xl overflow-hidden shadow-[0_10px_40px_rgba(0,0,0,0.1)]"
          >
            <img
              src={Munjal}
              alt="Munjal Constructions Website"
              className="w-full h-[600px] object-cover rounded-3xl"
            />
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            custom={1}
          >
            <h3 className="text-3xl md:text-4xl font-black mb-4">
              Munjal Constructions<span className="text-[#3EF4E4]">.</span>
            </h3>
            <p className="text-gray-800 text-lg leading-relaxed mb-6">
              A luxury construction brand built on trust and craftsmanship.  
              We crafted a minimalist portfolio that highlights projects through clean navigation,  
              immersive visuals, and WhatsApp-ready lead flows.
            </p>
          </motion.div>
        </div>

        {/* 🏢 Kumar Construction */}
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            custom={1}
            className="order-2 md:order-1"
          >
            <h3 className="text-3xl md:text-4xl font-black mb-4">
              Kumar Construction<span className="text-[#3EF4E4]">.</span>
            </h3>
            <p className="text-gray-800 text-lg leading-relaxed mb-6">
              For Delhi’s oldest P.O.P. contractor, we designed a digital identity  
              that reflects both legacy and modernity. The result — a timeless brand presence  
              with a simple, elegant digital interface.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={fadeUp}
            className="order-1 md:order-2 rounded-3xl overflow-hidden shadow-[0_10px_40px_rgba(0,0,0,0.1)]"
          >
            <img
              src={Kumar}
              alt="Kumar Construction Website"
              className="w-full h-[600px] object-cover rounded-3xl"
            />
          </motion.div>
        </div>
      </section>

      {/* 📊 RESULTS */}
      <section className="relative bg-[#0D0D0D] py-28 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-black mb-6">
            The Impact<span className="text-[#3EF4E4]">.</span>
          </h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto mb-20 leading-relaxed">
            After partnering with GrowthLayer, builders experienced a significant lift 
            in visibility, engagement, and high-quality leads — without extra ad spend.
          </p>

          <div className="grid sm:grid-cols-3 gap-10">
            {[
              { value: 40, suffix: "%", label: "Increase in Enquiries" },
              { value: 3, suffix: "x", label: "Improved Lead Quality" },
              { value: 50, suffix: "%", label: "Faster Client Responses" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: i * 0.15 }}
                viewport={{ once: true }}
                className="bg-[#101010] rounded-3xl border border-[#3EF4E4]/30 hover:border-[#3EF4E4]
                           shadow-[0_0_30px_rgba(62,244,228,0.1)] hover:shadow-[0_0_50px_rgba(62,244,228,0.25)]
                           p-10 text-center transform hover:-translate-y-2 duration-500"
              >
                <h3 className="text-6xl md:text-7xl font-black text-[#3EF4E4] mb-3">
                  <CountUp end={stat.value} duration={2.5} enableScrollSpy scrollSpyOnce />
                  {stat.suffix}
                </h3>
                <p className="text-gray-300 text-base font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <motion.section
        initial="hidden"
        whileInView="visible"
        variants={fadeUp}
        viewport={{ once: true }}
        className="py-20 bg-[#3EF4E4] text-black text-center"
      >
        <h2 className="text-4xl font-bold mb-4">Let’s Digitize Your Real Estate Brand.</h2>
        <p className="text-lg max-w-2xl mx-auto mb-8 opacity-90">
          Build credibility. Capture high-intent leads. 
          Showcase your projects with GrowthLayer’s conversion-driven websites and automations.
        </p>
        <button
          onClick={handleScrollToContact}
          className="px-10 py-4 bg-black text-white rounded-full font-bold hover:scale-105 transition-transform"
        >
          Get Started
        </button>
      </motion.section>

      <Footer />
    </div>
  );
}
